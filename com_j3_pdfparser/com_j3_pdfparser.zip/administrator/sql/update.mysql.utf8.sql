/* Only premium users are allowed to update a component */
